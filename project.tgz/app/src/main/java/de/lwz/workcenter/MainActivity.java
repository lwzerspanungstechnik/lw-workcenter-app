package de.lwz.workcenter;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * LW Workcenter – Workstation-App (Hülle um /mobil).
 * 1.3 (17.10.2026): Dateiauswahl aus der Seite durchreichen (Fotos an Aufträgen,
 * Verbesserungsvorschläge): ein <input type="file"> öffnet jetzt Kamera bzw. Galerie.
 * Ohne onShowFileChooser ignoriert ein WebView solche Eingabefelder stumm.
 */
public class MainActivity extends Activity {
    private WebView web;
    private static final String URL = "http://192.168.178.43:8080/mobil";
    private static final int ANFRAGE_DATEI = 4711;
    private static final String TAG = "LW-Workcenter";

    private ValueCallback<Uri[]> dateiRueckgabe;   // wartende Antwort an die Seite
    private Uri kameraZiel;                        // Datei, in die die Kamera schreibt

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> rueckgabe, FileChooserParams params) {
                // Eine evtl. noch offene Anfrage sauber beenden (sonst haengt die Seite)
                if (dateiRueckgabe != null) {
                    try { dateiRueckgabe.onReceiveValue(null); } catch (Exception ignored) { }
                }
                dateiRueckgabe = rueckgabe;
                kameraZiel = null;
                try {
                    Intent kamera = kameraIntent();
                    boolean nurKamera = params != null && params.isCaptureEnabled();   // <input capture="environment">
                    if (nurKamera && kamera != null) {
                        startActivityForResult(kamera, ANFRAGE_DATEI);
                        return true;
                    }
                    Intent auswahl = params != null ? params.createIntent() : null;
                    if (auswahl == null) {
                        auswahl = new Intent(Intent.ACTION_GET_CONTENT);
                        auswahl.addCategory(Intent.CATEGORY_OPENABLE);
                        auswahl.setType("image/*");
                    }
                    if (params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        auswahl.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    Intent chooser = Intent.createChooser(auswahl, "Foto wählen");
                    if (kamera != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{ kamera });
                    }
                    startActivityForResult(chooser, ANFRAGE_DATEI);
                    return true;
                } catch (Exception e) {
                    Log.w(TAG, "Dateiauswahl fehlgeschlagen: " + e);
                    dateiRueckgabe = null;
                    kameraZiel = null;
                    try { rueckgabe.onReceiveValue(null); } catch (Exception ignored) { }
                    return true;   // true = wir haben die Anfrage behandelt (abgebrochen), kein Doppel-Dialog
                }
            }
        });
        if (b == null) web.loadUrl(URL);
    }

    /** Kamera-Intent mit Zieldatei im App-Cache (FileProvider) – braucht KEINE Kamera-Berechtigung. */
    private Intent kameraIntent() {
        try {
            File ordner = new File(getCacheDir(), "fotos");
            if (!ordner.exists() && !ordner.mkdirs()) return null;
            // alte Aufnahmen aufraeumen (aelter als 1 Tag)
            File[] alte = ordner.listFiles();
            if (alte != null) {
                long grenze = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
                for (File f : alte) {
                    if (f.lastModified() < grenze && !f.delete()) Log.d(TAG, "Alte Aufnahme bleibt: " + f.getName());
                }
            }
            String name = "foto_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.GERMANY).format(new Date()) + ".jpg";
            File ziel = new File(ordner, name);
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", ziel);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            kameraZiel = uri;
            return i;
        } catch (Exception e) {
            Log.w(TAG, "Kamera nicht vorbereitet: " + e);
            kameraZiel = null;
            return null;
        }
    }

    @Override
    protected void onActivityResult(int anfrage, int ergebnis, Intent daten) {
        if (anfrage != ANFRAGE_DATEI) { super.onActivityResult(anfrage, ergebnis, daten); return; }
        ValueCallback<Uri[]> rueckgabe = dateiRueckgabe;
        dateiRueckgabe = null;
        Uri ziel = kameraZiel;
        kameraZiel = null;
        if (rueckgabe == null) return;
        Uri[] erg = null;
        if (ergebnis == RESULT_OK) {
            List<Uri> liste = new ArrayList<Uri>();
            if (daten != null) {
                ClipData clip = daten.getClipData();
                if (clip != null) {
                    for (int k = 0; k < clip.getItemCount(); k++) {
                        Uri u = clip.getItemAt(k).getUri();
                        if (u != null) liste.add(u);
                    }
                } else if (daten.getData() != null) {
                    liste.add(daten.getData());
                }
            }
            if (liste.isEmpty() && ziel != null) {
                liste.add(ziel);   // Kamera liefert kein data-Intent, nur die Zieldatei
            }
            if (!liste.isEmpty()) erg = liste.toArray(new Uri[0]);
        }
        try { rueckgabe.onReceiveValue(erg); } catch (Exception e) { Log.w(TAG, "Rueckgabe fehlgeschlagen: " + e); }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web.canGoBack()) { web.goBack(); return true; }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onSaveInstanceState(Bundle o){ super.onSaveInstanceState(o); web.saveState(o); }
    @Override protected void onRestoreInstanceState(Bundle i){ super.onRestoreInstanceState(i); web.restoreState(i); }
}
